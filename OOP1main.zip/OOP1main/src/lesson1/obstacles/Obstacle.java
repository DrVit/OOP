package lesson1.obstacles;

import lesson1.Competitors.Competitor;

public abstract class Obstacle {
    public abstract void doIt(Competitor competitor);
}
