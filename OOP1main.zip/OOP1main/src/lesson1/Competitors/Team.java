package lesson1.Competitors;

public class Team {
    String teamName;
    Competitor[] teamMembers = new Competitor[4];


    public Team(Competitor[] teamMembers){
        this.teamName = "Сборище мечты";
        this.teamMembers = teamMembers;
    }


    public Competitor[] getMembers(){
        return teamMembers;
    }


}
