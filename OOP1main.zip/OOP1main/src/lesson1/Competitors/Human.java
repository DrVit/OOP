package lesson1.Competitors;

public class Human implements Competitor{
    String name;
    Double maxRunDistance;
    Double maxJumpHeight;
    boolean onDistance;

    public boolean isOnDistance() {
        return onDistance;
    }

    public Human(String name, Double maxDistance, Double maxJump) {
        this.name = name;
        this.maxRunDistance = maxDistance;
        this.maxJumpHeight = maxJump;
        this.onDistance = true;
    }

    public void run(int distance){
        if (distance <=maxRunDistance){
            System.out.println(name + " " + " успешно справился с бегом на дистанцию " + distance);
        } else {
            System.out.println(name + " " + " не смог преодолеть бег на дистанцию " +  distance);
            onDistance = false;
        }
    }

    public void jump(int height){
        if (height <=maxJumpHeight){
            System.out.println(name + " " + " успешно справился с прыжком на высоту " + height);
        } else {
            System.out.println(name + " " + " не смог преодолеть прыгнуть на высоту " + height);
            onDistance = false;
        }
    }



}
